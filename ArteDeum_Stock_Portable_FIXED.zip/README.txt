# ArteDeum Stock & Sales

This is a portable browser version of the ArteDeum stock system.

## To use it on another computer

1. Unzip the folder.
2. Open `tool-stock.html` in Chrome or Edge.
3. Use the demo login:
   - Username: `admin`
   - Password: `admin123`

No installation is needed for the basic app.

## Moving your stock/customer data

The app stores data in the browser on each device.

On the old computer:
- Open the app and log in.
- Click **Backup data**.
- Keep the `.json` backup file.

On the new computer:
- Open the app.
- Log in.
- Click **Restore data**.
- Select the backup `.json` file.

The backup contains products, stock quantities, customers, sales and users.

## Barcode scanner

The barcode camera library is loaded from the internet, so barcode scanning needs an internet connection. The rest of the basic app works from the local HTML file.

## Important

This is a local prototype. It does not automatically sync stock between different devices. If two computers need to see the same live stock at the same time, the system would need a shared database/server.


FIXED VERSION NOTES
- On load, the app checks for duplicate products and keeps one copy. If a product exists with a barcode and a matching copy without one, it keeps the barcoded product. Products without barcodes are shown in purple and can now be saved.
- Before the first cleanup, a backup of the product list is stored in this browser under arteDeum-products-before-dedupe-v1. Keep using your existing Netlify site URL and back up data from the app before deploying.
- Product data is browser-local; this ZIP does not contain your live stock records.
